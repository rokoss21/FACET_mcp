# FACET MCP Server v1.0.2 Release

This release contains package configuration files for both Python and Node.js packages of the FACET MCP Server.

## 📦 Files Included:

### Python Package:
- `pyproject.toml` - Python package configuration
- Complete Python MCP server implementation

### Node.js Package:
- `package.json` - Node.js package configuration
- `tsconfig.json` - TypeScript configuration
- `README.md` - Package documentation

## 🚀 Installation:

### Python:
```bash
pip install facet-mcp-server
```

### Node.js:
```bash
npm install facet-mcp-server
```

## 📚 Links:
- [Main Repository](https://github.com/rokoss21/FACET_mcp)
- [FACET Main Project](https://github.com/rokoss21/FACET)
- [PyPI Package](https://pypi.org/project/facet-mcp-server/)
- [npm Package](https://www.npmjs.com/package/facet-mcp-server)

## 🎯 Features:
- 70+ passing tests
- TypeScript support
- WebSocket MCP protocol
- SIMD optimizations (3.7x faster)
- Schema validation
- Deterministic text processing

## 📄 License:
This project is licensed under the MIT License - see the LICENSE file for details.